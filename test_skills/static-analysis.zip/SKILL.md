---
name: static-analysis
description: Static analysis toolkit with CodeQL, Semgrep, and SARIF parsing for security vulnerability detection
metadata:
  version: "1.0.1"
  author: "t00000014"
---

