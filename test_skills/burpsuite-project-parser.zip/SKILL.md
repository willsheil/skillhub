---
name: burpsuite-project-parser
description: Search and extract data from Burp Suite project files (.burp) directly from the command line for use in Claude
metadata:
  version: "1.0.0"
  author: "t00000004"
---

