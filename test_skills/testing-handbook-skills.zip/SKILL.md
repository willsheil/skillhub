---
name: testing-handbook-skills
description: Skills from the Trail of Bits Application Security Testing Handbook (appsec.guide)
metadata:
  version: "1.0.0"
  author: "t00000015"
---

