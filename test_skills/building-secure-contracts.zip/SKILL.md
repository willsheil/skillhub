---
name: building-secure-contracts
description: Comprehensive smart contract security toolkit based on Trail of Bits' Building Secure Contracts framework. Includes vulnerability scanners for 6 blockchains and 5 development guideline assistants.
metadata:
  version: "1.0.1"
  author: "t00000002"
---

