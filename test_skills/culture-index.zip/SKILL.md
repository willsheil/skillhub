---
name: culture-index
description: Interprets Culture Index survey results for individuals and teams
metadata:
  version: "1.0.0"
  author: "t00000005"
---

